/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.COUPPLING;

import FREADER.FReader;
import MODELS.Coupling_M;
import MODELS.Variable_M;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Roshan Withanage
 */
public class CouplingController {

    private CouplingController() {
    }

    private static final CouplingController obj = new CouplingController();

    public static CouplingController getInstance() {
        return obj;
    }

    List<Coupling_M> coplingList = new ArrayList<Coupling_M>();

    private int lineNo = 0;
    private String programeStatement = "";
    private int Wr = 2;
    private int Nr = 0;
    private int Wmcms = 2;
    private int Nmcms = 0;
    private int Wmcmd = 3;
    private int Nmcmd = 0;
    private int Wmcrms = 3;
    private int Nmcrms = 0;
    private int Wmcrmd = 4;
    private int Nmcrmd = 0;
    private int Wrmcrms = 4;
    private int Nrmcrms = 0;
    private int Wrmcrmd = 5;
    private int Nrmcrmd = 0;
    private int Wrmcms = 3;
    private int Nrmcms = 0;
    private int Wrmcmd = 4;
    private int Nrmcmd = 0;
    private int Wmrgvs = 1;
    private int Nmrgvs = 0;
    private int Wmrgvd = 2;
    private int Nmrgvd = 0;
    private int Wrmrgvs = 1;
    private int Nrmrgvs = 0;
    private int Wrmrgvd = 2;
    private int Nrmrgvd = 0;
    private int Ccp;

    private boolean isRecursive = false;

    //REGEX patterns
    private String FINE_METHOD = "(public|protected|private|\\s)\\s?static?\\s?(byte|short|int|long|float|double|boolean|char|void)\\s\\w*\\s?\\([^\\)]*\\)\\s?{?";
    private String METHOD_CALLING_ITSELF = "\\s\\w*\\s?\\([^\\)]*\\);";
    private String FIND_OBJECT = "\\w*?\\s\\w*\\s=\\snew\\s\\w*?\\([^\\)]*\\);";
    private String FIND_METHOD_CALLING = "\\w*\\.\\w*\\(\\);";

    public List<Coupling_M> getComplexity(String filePath) {
        int status = 0;
        List<String> LineList = FReader.getInstance().getLineList(filePath);
        for (String line : LineList) {
            char charLine[] = line.toCharArray();
            for (char c : charLine) {
                if (c == '{') {
                    status++;
                } else if (c == '}') {
                    status--;
                }
            }

            programeStatement = line;
            Coupling_M obj = new Coupling_M(lineNo, programeStatement, Nr, Nmcms, Nmcmd, Nmcrms, Nmcrmd, Nrmcrms, Nrmcrmd, Nrmcms, Nrmcmd, Nmrgvs, Nmrgvd, Nrmrgvs, Nrmrgvd, Ccp);
            lineNo++;
            coplingList.add(obj);
        }

        return coplingList;
    }

}
