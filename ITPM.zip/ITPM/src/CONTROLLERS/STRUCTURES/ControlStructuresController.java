/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.STRUCTURES;

import FREADER.FReader;
import MODELS.ControlStructures_M;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Roshan Withanage
 */
public class ControlStructuresController {

    private ControlStructuresController() {
    }
    private static final ControlStructuresController obj = new ControlStructuresController();

    public static ControlStructuresController getInstance() {
        return obj;
    }

    List<ControlStructures_M> csList = new ArrayList<ControlStructures_M>();

    private int lineNo;
    private String programStatement;
    private int Wtcs;
    private int NC;
    private int Ccspps;
    private int Ccs;

    private String status = "Not Found";
    private int temp = 0;

    //REGEX PATTERNS
    public String CONTROL_STRUCTURE_IF_ELSEIF = "\\s?if\\s?\\(|\\selse if\\s?\\(";
    public String CONTROL_STRUCTURE_FOR_WHILE_DOWHILE = "\\s?for\\s?\\(|\\swhile\\s?\\(";
    public String CONTROL_STRUCTURE_FOR_SWITCH = "\\sswitch\\s?\\(";
    public String CONTROL_STRUCTURE_FOR_CASE = "case\\s?:";

    private void reset() {
        programStatement = "";
        Wtcs = 0;
        NC = 0;
        Ccspps = 0;
        Ccs = 0;
    }

    public List<ControlStructures_M> getComplexity(String filePath) {
        lineNo = 0;

        List<String> LineList = FReader.getInstance().getLineList(filePath);
        for (String line : LineList) {
            //if else if
            Pattern ifPattern = Pattern.compile(CONTROL_STRUCTURE_IF_ELSEIF);
            Matcher ifeMatcher = ifPattern.matcher(line);
            while (ifeMatcher.find()) {
                Wtcs = 2;
                NC++;
            }
            //for while do-while
            Pattern forPattern = Pattern.compile(CONTROL_STRUCTURE_FOR_WHILE_DOWHILE);
            Matcher forMatcher = forPattern.matcher(line);
            while (forMatcher.find()) {
                Wtcs = 3;
                NC++;
            }
            //switch
            Pattern switchPattern = Pattern.compile(CONTROL_STRUCTURE_FOR_SWITCH);
            Matcher switchMatcher = switchPattern.matcher(line);
            while (switchMatcher.find()) {
                Wtcs = 2;
                NC++;
            }
            //case
            Pattern casePattern = Pattern.compile(CONTROL_STRUCTURE_FOR_CASE);
            Matcher caseMatcher = casePattern.matcher(line);
            while (caseMatcher.find()) {
                Wtcs = 1;
                NC++;
            }

            if (status.equals("Found") && Wtcs != 0) {
                Ccspps = temp;
                System.out.println(line + " found " + temp + " cc " + Ccspps);
            } else {
                Ccspps = 0;
                System.out.println(line + " test " + temp + " cc " + Ccspps);
            }
            lineNo++;
            programStatement = line;
            Ccs = (Wtcs * NC) + Ccspps;

            ControlStructures_M obj = new ControlStructures_M(lineNo, programStatement, Wtcs, NC, Ccspps, Ccs);
            csList.add(obj);

            if (Wtcs != 0) {
                status = "Found";
                temp = Ccs;
                Ccspps = 0;
            } else {
                status = "Not Found";
                temp = 0;
            }
            reset();
        }

        return csList;
    }
}
