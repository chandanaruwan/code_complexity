/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.SIZE_VARIABLES_METHODS;

import FREADER.FReader;
import MODELS.Size_M;
import static CONTROLLERS.SIZE_VARIABLES_METHODS.RegexPatterns.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Roshan Withanage
 */
public class SizeController {

    private int Cs;
    private int Wkw = 1;
    private int Nkw = 0;
    private int Wid = 1;
    private int Nid = 0;
    private int Wop = 1;
    private int Nop = 0;
    private int Wnv = 1;
    private int Nnv = 0;
    private int Wsl = 1;
    private int Nsl = 0;
    private int index = 0;
    private String ProgramStatements = "";



    List<Size_M> sizeModelList = new ArrayList<Size_M>();

    private SizeController() {
    }
    private static final SizeController obj = new SizeController();

    public static SizeController getInstance() {
        return obj;
    }

    private void reset() {
        Nkw = 0;
        Nid = 0;
        Nop = 0;
        Nnv = 0;
        Nsl = 0;
        ProgramStatements = "";
    }

    public List<Size_M> getComplexity(String filePath) {
        index = 0;

        List<String> LineList = FReader.getInstance().getLineList(filePath);
        for (String line : LineList) {
            
            //find key words
            Pattern keywordPattern = Pattern.compile(KEY_WORDS);
            Matcher keywordMatcher = keywordPattern.matcher(line);
            while (keywordMatcher.find()) {
                Nkw++;
            }
            //find operators
            Pattern operatorPattern = Pattern.compile(OPERATORS);
            Matcher operatorMatcher = operatorPattern.matcher(line);
            while (operatorMatcher.find()) {
                Nop++;
            }
            //find Indentifier
            //find class, system methods
            Pattern identifireClassPattern = Pattern.compile(IDENTIFIERS_CLASS);
            Matcher identifireClassMatcher = identifireClassPattern.matcher(line);
            while (identifireClassMatcher.find()) {
                Nid++;
            }
            //find Indentifier
            //find objects
            Pattern identifireObjectPattern = Pattern.compile(IDENTIFIERS_OBJECT);
            Matcher identifireObjectMatcher = identifireObjectPattern.matcher(line);
            while (identifireObjectMatcher.find()) {
                Nid++;
            }
            //find Indentifier
            //find methods
            Pattern identifireMethodPattern = Pattern.compile(IDENTIFIERS_METHOD);
            Matcher identifireMethodMatcher = identifireMethodPattern.matcher(line);
            while (identifireMethodMatcher.find()) {
                Nid++;
            }
            //find Indentifier
            //find variable
            Pattern identifireParameterPattern = Pattern.compile(IDENTIFIERS_PARAMETER);
            Matcher identifireParameterMatcher = identifireParameterPattern.matcher(line);
            while (identifireParameterMatcher.find()) {
                Pattern identifireVariablePattern = Pattern.compile(IDENTIFIERS_VARIABLE);
                Matcher identifireVariableMatcher = identifireVariablePattern.matcher(line);
                while (identifireVariableMatcher.find()) {
                    Nid++;
                }
            }
            //find Indentifier
            //find ID operator
            Pattern identifireIODPattern = Pattern.compile(ID_OPERATORS);
            Matcher identifireIDOMatcher = identifireIODPattern.matcher(line);
            while (identifireIDOMatcher.find()) {
                Nid++;
            }
            //find Indentifier
            //find Relational operator
            Pattern identifireRelationPattern = Pattern.compile(RELATIONAL_OPERATORS);
            Matcher identifireRelationMatcher = identifireRelationPattern.matcher(line);
            while (identifireRelationMatcher.find()) {
                Nid++;
                Nid++;
            }
            //find Numerical value
            Pattern numericPattern = Pattern.compile(NUMERIC);
            Matcher numericMatcher = numericPattern.matcher(line);
            while (numericMatcher.find()) {
                Nnv++;
            }
            //find String literals
            //find Numerical value
            Pattern stringPattern = Pattern.compile(STRING_LITERAL);
            Matcher stringMatcher = stringPattern.matcher(line);
            while (stringMatcher.find()) {
                Nsl++;
            }
            ProgramStatements = line;
            Cs = ((Wkw * Nkw) + (Wid * Nid) + (Wop * Nop) + (Wnv * Nnv) + (Wsl * Nsl));

            index++;
            Size_M obj = new Size_M(Cs, Nkw, Nid, Nop, Nnv, Nsl, index, ProgramStatements);
            sizeModelList.add(obj);
            reset();
        }

        return sizeModelList;
    }

}
