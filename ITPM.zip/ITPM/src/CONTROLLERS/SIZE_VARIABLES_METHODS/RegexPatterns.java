/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.SIZE_VARIABLES_METHODS;

/**
 *
 * @author Roshan Withanage
 */
public class RegexPatterns {

    public static String KEY_WORDS = "(abstract|break|catch|class|continue|default|do|else|enum|extends|final|finally|implements|import|instanceof|interface|native|new|null|package|private|protected|public|return|static|strictfp|super|synchronized|this|throws|transient|try|void|volatile)";
    public static String OPERATORS = "\\%|\\/|\\*|-{1,2}|\\+{1,2}|<=|>=|<{1,3}|>{1,3}|!=|={1,2}|&{2}|\\|{1,2}|!|\\^|~|,|\\.|:{2}|->";
    public static String IDENTIFIERS_CLASS = "class|System|out|println";
    public static String IDENTIFIERS_OBJECT = "=\\snew\\s\\w*\\([^\\)]*\\)";
    public static String IDENTIFIERS_METHOD = "(public|protected|private|static|\\s) +[\\w\\<\\>\\[\\]]+\\s+(\\w+) *\\([^\\)]*\\) *(\\{?|[^;])";
    public static String IDENTIFIERS_VARIABLE = "(byte|short|int|long|float|double|boolean|char)\\s\\w*\\s?=\\s?\\w*;";
    public static String ID_OPERATORS = "\\w*\\+{1,2}|\\w*\\-{1,2}";
    public static String NUMERIC = "\\d+\\;?";
    public static String STRING_LITERAL = "\".*\"";
    public static String IDENTIFIERS_PARAMETER = "\\([^\\)]*\\)";
    public static String RELATIONAL_OPERATORS = "/<=|>=|<|>|!=|==/g";
    public static String RETURN_TYPE_PRIMITIVE = "(byte|short|int|long|float|double|boolean|char)";
    public static String RETURN_TYPE_VOID = "void";
    public static String PARAMETER_VOID = "\\(\\)";
    public static String PARAMETER_PRIMITIVE = "\\(\\s*?.*?(byte|short|int|long|float|double|boolean|char)\\s*?.*?\\)";
    public static String INHERITANCE_CLASS = "class";
    public static String INHERITANCE_INTERFACE = "implements|,";
    public static String CONTROL_STRUCTURE_IF_ELSEIF = "\\s?if\\s?\\(|\\selse if\\s?\\(";
    public static String CONTROL_STRUCTURE_FOR_WHILE_DOWHILE = "\\s?for\\s?\\(|\\swhile\\s?\\(";
    public static String CONTROL_STRUCTURE_FOR_SWITCH = "\\sswitch\\s?\\(";
    public static String CONTROL_STRUCTURE_FOR_CASE = "case\\s?:";
    
}
