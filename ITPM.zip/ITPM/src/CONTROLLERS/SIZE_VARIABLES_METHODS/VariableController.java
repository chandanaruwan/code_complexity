/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.SIZE_VARIABLES_METHODS;

import FREADER.FReader;
import MODELS.Variable_M;
import static CONTROLLERS.SIZE_VARIABLES_METHODS.RegexPatterns.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Roshan Withanage
 */
public class VariableController {

    private int Cv;
    private int Wvs;
    private int Wpdtv = 1;
    private int Npdtv;
    private int Wcdtv = 2;
    private int Ncdtv;
    private int index = 0;
    private boolean CS = true;
    private String ProgramStatements;

    List<Variable_M> sizeModelList = new ArrayList<Variable_M>();

    private VariableController() {
    }
    private static final VariableController obj = new VariableController();

    public static VariableController getInstance() {
        return obj;
    }

    private void reset() {
        Cv = 0;
        Wvs = 0;
        Npdtv = 0;
        Ncdtv = 0;
        CS = true;
    }

    public List<Variable_M> getComplexity(String filePath) {
        index = 0;
        int GorL = 0;
        CS = true;

        List<String> LineList = FReader.getInstance().getLineList(filePath);
        for (String line : LineList) {
            char charLine[] = line.toCharArray();
            for (char c : charLine) {
                if (c == '{') {
                    GorL++;
                } else if (c == '}') {
                    GorL--;
                }
                if (c == '(') {
                    CS = false;
                }
            }

            //find primitive variables
            //ignore parameter
            Pattern identifireParameterPattern = Pattern.compile(IDENTIFIERS_PARAMETER);
            Matcher identifireParameterMatcher = identifireParameterPattern.matcher(line);
            while (identifireParameterMatcher.find()) {
                CS = false;
            }
            //find primitive variables
            Pattern identifireVariablePattern = Pattern.compile(IDENTIFIERS_VARIABLE);
            Matcher identifireVariableMatcher = identifireVariablePattern.matcher(line);
            while (identifireVariableMatcher.find()) {
                if (CS) {
                    Npdtv++;
                    if (GorL == 1) {
                        Wvs = 2;
                    } else {
                        Wvs = 1;
                    }
                }
            }
            //find composite variables
            Pattern identifireObjectPattern = Pattern.compile(IDENTIFIERS_OBJECT);
            Matcher identifireObjectMatcher = identifireObjectPattern.matcher(line);
            while (identifireObjectMatcher.find()) {
                Ncdtv++;
                if (GorL == 1) {
                    Wvs = 2;
                } else {
                    Wvs = 1;
                }
            }

            index++;
            ProgramStatements = line;
            Cv = Wvs * ((Wpdtv * Npdtv) + (Wcdtv * Ncdtv));

            Variable_M obj = new Variable_M(Cv, Wvs, Npdtv, Ncdtv, index, ProgramStatements);
            sizeModelList.add(obj);
            reset();
        }

        return sizeModelList;
    }

}
