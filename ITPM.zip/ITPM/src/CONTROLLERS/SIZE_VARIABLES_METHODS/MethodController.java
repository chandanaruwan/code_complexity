/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.SIZE_VARIABLES_METHODS;

import FREADER.FReader;
import MODELS.Method_M;
import static CONTROLLERS.SIZE_VARIABLES_METHODS.RegexPatterns.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Roshan Withanage
 */
public class MethodController {

    private int Cm;
    private int Wmrt;
    private int Wpdtp = 1;
    private int Npdtp;
    private int Wcdtp = 2;
    private int Ncdtp;
    private int index = 0;
    private String ProgramStatements;

    List<Method_M> methodeModelList = new ArrayList<Method_M>();

    private MethodController() {
    }
    private static final MethodController obj = new MethodController();

    public static MethodController getInstance() {
        return obj;
    }

    private void reset() {
        Wmrt = 0;
        Npdtp = 0;
        Ncdtp = 0;
        Cm = 0;
    }

    public List<Method_M> getComplexity(String filePath) {
        index = 0;

        List<String> LineList = FReader.getInstance().getLineList(filePath);
        for (String line : LineList) {
            String returnType = "";
            String parameterType = "";
            //find methods
            //ignore parameter
            Pattern identifireMethordPattern = Pattern.compile(IDENTIFIERS_METHOD);
            Matcher identifireMethordMatcher = identifireMethordPattern.matcher(line);
            while (identifireMethordMatcher.find()) {
                //find primitive return type
                Pattern identifirePrimitiveReturnPattern = Pattern.compile(RETURN_TYPE_PRIMITIVE);
                Matcher identifirePrimitiveReturnMatcher = identifirePrimitiveReturnPattern.matcher(line);
                while (identifirePrimitiveReturnMatcher.find()) {
                    returnType = "primitive";
                }
                //find void return type
                Pattern identifireVoidReturnPattern = Pattern.compile(RETURN_TYPE_VOID);
                Matcher identifireVoidReturnMatcher = identifireVoidReturnPattern.matcher(line);
                while (identifireVoidReturnMatcher.find()) {
                    returnType = "void";
                }

                if (returnType.equals("primitive")) {
                    Wmrt = 1;
                } else if (returnType.equals("void")) {
                    Wmrt = 0;
                } else {
                    Wmrt = 2;
                }
                //find primitive parameter
                Pattern identifirePrimitiveParameterPattern = Pattern.compile(PARAMETER_PRIMITIVE);
                Matcher identifirePrimitiveParameterMatcher = identifirePrimitiveParameterPattern.matcher(line);
                while (identifirePrimitiveParameterMatcher.find()) {
                    parameterType = "primitive";
                }
                //find void parameter
                Pattern identifireVoidParameterPattern = Pattern.compile(PARAMETER_VOID);
                Matcher identifireVoidParameterMatcher = identifireVoidParameterPattern.matcher(line);
                while (identifireVoidParameterMatcher.find()) {
                    parameterType = "void";
                }
                if (parameterType.equals("primitive")) {
                    Npdtp++;
                } else if (parameterType.equals("void")) {

                } else {
                    Ncdtp++;
                }

            }

            ProgramStatements = line;
            index++;
            Cm = Wmrt + (Wpdtp * Npdtp) + (Wcdtp * Ncdtp);
            Method_M obj = new Method_M(Cm, Wmrt, Npdtp, Ncdtp, index, ProgramStatements);
            methodeModelList.add(obj);
            reset();
        }

        return methodeModelList;
    }

}
