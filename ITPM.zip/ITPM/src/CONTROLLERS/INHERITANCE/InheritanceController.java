/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLERS.INHERITANCE;

import FREADER.FReader;
import MODELS.Inheritance_M;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Roshan Withanage
 */
public class InheritanceController {

    private int count = 0;
    private String className = "";
    private int No_of_direct_inheritances = 0;
    private int No_of_indirect_inheritances = 0;
    private int Total_inheritances = 0;
    private int Ci = 0;

    //REGEX PATTERNS
    public static String INHERITANCE_CLASS = "extends";
    public static String INHERITANCE_INTERFACE = "implements|,";
    public static String FIND_CLASS = "class\\s\\w*";

    List<Inheritance_M> inheritanceModelList = new ArrayList<Inheritance_M>();

    private InheritanceController() {
    }
    private static final InheritanceController obj = new InheritanceController();

    public static InheritanceController getInstance() {
        return obj;
    }

    private void reset() {
        className = "";
        No_of_direct_inheritances = 0;
        No_of_indirect_inheritances = 0;
        Total_inheritances = 0;
        Ci = 0;
    }

    public List<Inheritance_M> getComplexity(String filePath) {
        count = 0;

        List<String> LineList = FReader.getInstance().getLineList(filePath);
        for (String line : LineList) {
            //inherit by class
            Pattern directInheritancePattern = Pattern.compile(INHERITANCE_CLASS);
            Matcher directInheritanceMatcher = directInheritancePattern.matcher(line);
            while (directInheritanceMatcher.find()) {
                No_of_direct_inheritances++;
                Ci++;
            }
            //inherit by interface
            Pattern indirectInheritancePattern = Pattern.compile(INHERITANCE_INTERFACE);
            Matcher indirectInheritanceMatcher = indirectInheritancePattern.matcher(line);
            while (indirectInheritanceMatcher.find()) {
                No_of_indirect_inheritances++;
                Ci++;
            }
            //find class name
            Pattern classNamePattern = Pattern.compile(FIND_CLASS);
            Matcher classNameMatcher = classNamePattern.matcher(line);
            if (classNameMatcher.find()) {
                className = classNameMatcher.group().replaceFirst("class ", "");
                System.out.println(classNameMatcher.group().replaceFirst("class ", ""));
            }

            if (Ci > 4) {
                Ci = 4;
            }

            count++;
            Total_inheritances = No_of_direct_inheritances + No_of_indirect_inheritances;
            System.out.println(No_of_indirect_inheritances);
            Inheritance_M obj = new Inheritance_M(count, className, No_of_direct_inheritances, No_of_indirect_inheritances, Total_inheritances, Ci);
            inheritanceModelList.add(obj);
            reset();
        }

        return inheritanceModelList;
    }

}
