/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELS;

/**
 *
 * @author Roshan Withanage
 */
public class Variable_M {

    private int Cv;
    private int Wvs;
    private int Npdtv;
    private int Ncdtv;
    private int index;
    private String ProgramStatements;

    public Variable_M() {
    }

    public Variable_M(int Cv, int Wvs, int Npdtv, int Ncdtv, int index, String ProgramStatements) {
        this.Cv = Cv;
        this.Wvs = Wvs;
        this.Npdtv = Npdtv;
        this.Ncdtv = Ncdtv;
        this.index = index;
        this.ProgramStatements = ProgramStatements;
    }

    public int getCv() {
        return Cv;
    }

    public void setCv(int Cv) {
        this.Cv = Cv;
    }

    public int getWvs() {
        return Wvs;
    }

    public void setWvs(int Wvs) {
        this.Wvs = Wvs;
    }

    public int getNpdtv() {
        return Npdtv;
    }

    public void setNpdtv(int Npdtv) {
        this.Npdtv = Npdtv;
    }

    public int getNcdtv() {
        return Ncdtv;
    }

    public void setNcdtv(int Ncdtv) {
        this.Ncdtv = Ncdtv;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getProgramStatements() {
        return ProgramStatements;
    }

    public void setProgramStatements(String ProgramStatements) {
        this.ProgramStatements = ProgramStatements;
    }

}
