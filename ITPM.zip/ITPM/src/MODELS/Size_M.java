/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELS;

/**
 *
 * @author Roshan Withanage
 */
public class Size_M {

    public int Cs;
    public int Nkw;
    public int Nid;
    public int Nop;
    public int Nnv;
    public int Nsl;
    public int index;
    public String ProgramStatements;

    public Size_M() {
    }

    public Size_M(int Cs, int Nkw, int Nid, int Nop, int Nnv, int Nsl, int index, String ProgramStatements) {
        this.Cs = Cs;
        this.Nkw = Nkw;
        this.Nid = Nid;
        this.Nop = Nop;
        this.Nnv = Nnv;
        this.Nsl = Nsl;
        this.index = index;
        this.ProgramStatements = ProgramStatements;
    }

    public int getCs() {
        return Cs;
    }

    public void setCs(int Cs) {
        this.Cs = Cs;
    }

    public int getNkw() {
        return Nkw;
    }

    public void setNkw(int Nkw) {
        this.Nkw = Nkw;
    }

    public int getNid() {
        return Nid;
    }

    public void setNid(int Nid) {
        this.Nid = Nid;
    }

    public int getNop() {
        return Nop;
    }

    public void setNop(int Nop) {
        this.Nop = Nop;
    }

    public int getNnv() {
        return Nnv;
    }

    public void setNnv(int Nnv) {
        this.Nnv = Nnv;
    }

    public int getNsl() {
        return Nsl;
    }

    public void setNsl(int Nsl) {
        this.Nsl = Nsl;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getProgramStatements() {
        return ProgramStatements;
    }

    public void setProgramStatements(String ProgramStatements) {
        this.ProgramStatements = ProgramStatements;
    }

}
