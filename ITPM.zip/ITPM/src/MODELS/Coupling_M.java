/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELS;

/**
 *
 * @author Roshan Withanage
 */
public class Coupling_M {

    private int lineNo;
    private String programeStatement;
    private int Nr;
    private int Nmcms;
    private int Nmcmd;
    private int Nmcrms;
    private int Nmcrmd;
    private int Nrmcrms;
    private int Nrmcrmd;
    private int Nrmcms;
    private int Nrmcmd;
    private int Nmrgvs;
    private int Nmrgvd;
    private int Nrmrgvs;
    private int Nrmrgvd;
    private int Ccp;

    public Coupling_M() {
    }

    public Coupling_M(int lineNo, String programeStatement, int Nr, int Nmcms, int Nmcmd, int Nmcrms, int Nmcrmd, int Nrmcrms, int Nrmcrmd, int Nrmcms, int Nrmcmd, int Nmrgvs, int Nmrgvd, int Nrmrgvs, int Nrmrgvd, int Ccp) {
        this.lineNo = lineNo;
        this.programeStatement = programeStatement;
        this.Nr = Nr;
        this.Nmcms = Nmcms;
        this.Nmcmd = Nmcmd;
        this.Nmcrms = Nmcrms;
        this.Nmcrmd = Nmcrmd;
        this.Nrmcrms = Nrmcrms;
        this.Nrmcrmd = Nrmcrmd;
        this.Nrmcms = Nrmcms;
        this.Nrmcmd = Nrmcmd;
        this.Nmrgvs = Nmrgvs;
        this.Nmrgvd = Nmrgvd;
        this.Nrmrgvs = Nrmrgvs;
        this.Nrmrgvd = Nrmrgvd;
        this.Ccp = Ccp;
    }

    public int getLineNo() {
        return lineNo;
    }

    public void setLineNo(int lineNo) {
        this.lineNo = lineNo;
    }

    public String getProgrameStatement() {
        return programeStatement;
    }

    public void setProgrameStatement(String programeStatement) {
        this.programeStatement = programeStatement;
    }

    public int getNr() {
        return Nr;
    }

    public void setNr(int Nr) {
        this.Nr = Nr;
    }

    public int getNmcms() {
        return Nmcms;
    }

    public void setNmcms(int Nmcms) {
        this.Nmcms = Nmcms;
    }

    public int getNmcmd() {
        return Nmcmd;
    }

    public void setNmcmd(int Nmcmd) {
        this.Nmcmd = Nmcmd;
    }

    public int getNmcrms() {
        return Nmcrms;
    }

    public void setNmcrms(int Nmcrms) {
        this.Nmcrms = Nmcrms;
    }

    public int getNmcrmd() {
        return Nmcrmd;
    }

    public void setNmcrmd(int Nmcrmd) {
        this.Nmcrmd = Nmcrmd;
    }

    public int getNrmcrms() {
        return Nrmcrms;
    }

    public void setNrmcrms(int Nrmcrms) {
        this.Nrmcrms = Nrmcrms;
    }

    public int getNrmcrmd() {
        return Nrmcrmd;
    }

    public void setNrmcrmd(int Nrmcrmd) {
        this.Nrmcrmd = Nrmcrmd;
    }

    public int getNrmcms() {
        return Nrmcms;
    }

    public void setNrmcms(int Nrmcms) {
        this.Nrmcms = Nrmcms;
    }

    public int getNrmcmd() {
        return Nrmcmd;
    }

    public void setNrmcmd(int Nrmcmd) {
        this.Nrmcmd = Nrmcmd;
    }

    public int getNmrgvs() {
        return Nmrgvs;
    }

    public void setNmrgvs(int Nmrgvs) {
        this.Nmrgvs = Nmrgvs;
    }

    public int getNmrgvd() {
        return Nmrgvd;
    }

    public void setNmrgvd(int Nmrgvd) {
        this.Nmrgvd = Nmrgvd;
    }

    public int getNrmrgvs() {
        return Nrmrgvs;
    }

    public void setNrmrgvs(int Nrmrgvs) {
        this.Nrmrgvs = Nrmrgvs;
    }

    public int getNrmrgvd() {
        return Nrmrgvd;
    }

    public void setNrmrgvd(int Nrmrgvd) {
        this.Nrmrgvd = Nrmrgvd;
    }

    public int getCcp() {
        return Ccp;
    }

    public void setCcp(int Ccp) {
        this.Ccp = Ccp;
    }

    

}
