/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODELS;

/**
 *
 * @author Roshan Withanage
 */
public class Method_M {

    private int Cm;
    private int Wmrt;
    private int Npdtp;
    private int Ncdtp;
    private int index;
    private String ProgramStatements;

    public Method_M() {
    }

    public Method_M(int Cm, int Wmrt, int Npdtp, int Ncdtp, int index, String ProgramStatements) {
        this.Cm = Cm;
        this.Wmrt = Wmrt;
        this.Npdtp = Npdtp;
        this.Ncdtp = Ncdtp;
        this.index = index;
        this.ProgramStatements = ProgramStatements;
    }

    public int getCm() {
        return Cm;
    }

    public void setCm(int Cm) {
        this.Cm = Cm;
    }

    public int getWmrt() {
        return Wmrt;
    }

    public void setWmrt(int Wmrt) {
        this.Wmrt = Wmrt;
    }

    public int getNpdtp() {
        return Npdtp;
    }

    public void setNpdtp(int Npdtp) {
        this.Npdtp = Npdtp;
    }

    public int getNcdtp() {
        return Ncdtp;
    }

    public void setNcdtp(int Ncdtp) {
        this.Ncdtp = Ncdtp;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getProgramStatements() {
        return ProgramStatements;
    }

    public void setProgramStatements(String ProgramStatements) {
        this.ProgramStatements = ProgramStatements;
    }

}
